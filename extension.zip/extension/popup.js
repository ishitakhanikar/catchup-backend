document.addEventListener('DOMContentLoaded', async () => {
    // Agenda Default Logic
    const agendaInput = document.getElementById('agenda');
    const setDefaultBtn = document.getElementById('set-default-btn');
    const defaultSavedMsg = document.getElementById('default-saved-msg');

    chrome.storage.local.get(['defaultAgenda'], (result) => {
        if (result.defaultAgenda) {
            agendaInput.value = result.defaultAgenda;
        }
    });

    setDefaultBtn.addEventListener('click', () => {
        const text = agendaInput.value;
        chrome.storage.local.set({ defaultAgenda: text }, () => {
            defaultSavedMsg.classList.remove('hidden');
            setTimeout(() => defaultSavedMsg.classList.add('hidden'), 2000);
        });
    });

    // Tabs logic
    const tabs = document.querySelectorAll('.tab');
    const tabContents = document.querySelectorAll('.tab-content');

    tabs.forEach(tab => {
        tab.addEventListener('click', () => {
            tabs.forEach(t => t.classList.remove('active'));
            tabContents.forEach(c => c.classList.add('hidden'));

            tab.classList.add('active');
            document.getElementById(`${tab.dataset.tab}-content`).classList.remove('hidden');
        });
    });

    // File Input Logic
    const fileInput = document.getElementById('audio-file');
    const fileNameDisplay = document.getElementById('file-name-display');
    const generateBtn = document.getElementById('generate-btn');

    fileInput.addEventListener('change', (e) => {
        if (e.target.files.length > 0) {
            fileNameDisplay.textContent = e.target.files[0].name;
            generateBtn.disabled = false;
        } else {
            fileNameDisplay.textContent = 'No file selected';
            generateBtn.disabled = true;
        }
    });

    // Recording Logic - sync with Background Worker
    const recordBtn = document.getElementById('record-btn');
    const recordStatus = document.getElementById('record-status');
    const btnText = recordBtn.querySelector('.btn-text');
    let recordedBlob = null;
    let isRecordingLocal = false;

    // Helper: Format timer
    function formatTime(seconds) {
        const mins = Math.floor(seconds / 60).toString().padStart(2, '0');
        const secs = (seconds % 60).toString().padStart(2, '0');
        return `${mins}:${secs}`;
    }

    // Helper: Convert base64 data URL back to Blob
    function dataURLtoBlob(dataurl) {
        if (!dataurl) return null;
        let arr = dataurl.split(','), mime = arr[0].match(/:(.*?);/)[1],
            bstr = atob(arr[1]), n = bstr.length, u8arr = new Uint8Array(n);
        while(n--){
            u8arr[n] = bstr.charCodeAt(n);
        }
        return new Blob([u8arr], {type:mime});
    }

    // Initialize state from background
    chrome.runtime.sendMessage({ type: 'GET_STATE' }, (response) => {
        if (response.isRecording) {
            isRecordingLocal = true;
            recordBtn.classList.add('recording');
            btnText.textContent = 'Stop Recording';
            recordStatus.textContent = `Recording... ${formatTime(response.seconds)}`;
            recordStatus.classList.remove('hidden');
            generateBtn.disabled = true;
        } else if (response.recordedDataUrl) {
            recordedBlob = dataURLtoBlob(response.recordedDataUrl);
            recordStatus.textContent = 'Recording saved. Ready to generate.';
            recordStatus.classList.remove('hidden');
            generateBtn.disabled = false;
            // Clear backend dataUrl if needed, or keep it
        }
    });

    // Listen for background updates
    chrome.runtime.onMessage.addListener((message) => {
        if (message.type === 'TIMER_UPDATE') {
            recordStatus.textContent = `Recording... ${formatTime(message.seconds)}`;
        } else if (message.type === 'RECORDING_COMPLETE') {
            recordedBlob = dataURLtoBlob(message.data);
            isRecordingLocal = false;
            recordBtn.classList.remove('recording');
            btnText.textContent = 'Start Recording';
            recordStatus.textContent = 'Recording saved. Ready to generate.';
            generateBtn.disabled = false;
        }
    });

    recordBtn.addEventListener('click', async () => {
        if (!isRecordingLocal) {
            // Check for mic permissions explicitly before telling background to start
            try {
                const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
                // We don't need it here, just needed to prompt permission in the main window
                stream.getTracks().forEach(track => track.stop());
            } catch(err) {
                alert("Microphone access denied. Please allow it.");
                return;
            }

            chrome.runtime.sendMessage({ type: 'START_RECORDING' }, (res) => {
                if (res && res.error) {
                    alert('Error starting recording: ' + res.error);
                } else {
                    isRecordingLocal = true;
                    recordBtn.classList.add('recording');
                    btnText.textContent = 'Stop Recording';
                    recordStatus.textContent = `Recording... 00:00`;
                    recordStatus.classList.remove('hidden');
                    generateBtn.disabled = true;
                    recordedBlob = null;
                }
            });
        } else {
            chrome.runtime.sendMessage({ type: 'STOP_RECORDING' });
            // The background will return RECORDING_COMPLETE when done
            recordStatus.textContent = `Saving...`;
            isRecordingLocal = false;
            recordBtn.classList.remove('recording');
            btnText.textContent = 'Start Recording';
        }
    });

    // Generate Button Logic
    const loadingSection = document.getElementById('loading');
    const resultSection = document.getElementById('result');

    let pdfBlobUrl = null;

    generateBtn.addEventListener('click', async () => {
        const agendaText = document.getElementById('agenda').value;
        if (!agendaText.trim()) {
            alert("Please provide a meeting agenda so the AI can focus on key points.");
            return;
        }

        const formData = new FormData();
        formData.append('agenda', agendaText);

        const activeTab = document.querySelector('.tab.active').dataset.tab;
        if (activeTab === 'upload' && fileInput.files.length > 0) {
            formData.append('audio', fileInput.files[0]);
        } else if (activeTab === 'record' && recordedBlob) {
            formData.append('audio', recordedBlob, 'recording.webm');
        } else {
            alert("Please record or select an audio file first.");
            return;
        }

        // Show loading state
        loadingSection.classList.remove('hidden');
        generateBtn.classList.add('hidden');

        try {
            const response = await fetch('https://catchup-backend-production.up.railway.app/api/v1/generate-mom', {
                method: 'POST',
                body: formData
            });

            if (!response.ok) {
                const errorData = await response.json();
                throw new Error(errorData.detail || 'Server returned an error');
            }

            const pdfBlob = await response.blob();
            if (pdfBlobUrl) URL.revokeObjectURL(pdfBlobUrl); 
            pdfBlobUrl = URL.createObjectURL(pdfBlob);

            loadingSection.classList.add('hidden');
            resultSection.classList.remove('hidden');
            
            // clear the recorded state in backend to maintain cleanliness
            chrome.runtime.sendMessage({ type: 'CLEAR_RECORDING' });
            recordedBlob = null;
        } catch (err) {
            alert("Error generating MoM: " + err.message);
            loadingSection.classList.add('hidden');
            generateBtn.classList.remove('hidden');
            console.error(err);
        }
    });

    // Download PDF logic
    document.getElementById('download-pdf').addEventListener('click', () => {
        if (!pdfBlobUrl) return;
        
        let filename = document.getElementById('pdf-filename').value.trim();
        if (!filename) filename = 'Minutes_of_Meeting';
        if (!filename.endsWith('.pdf')) filename += '.pdf';
        
        const a = document.createElement('a');
        a.href = pdfBlobUrl;
        a.download = filename;
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);
    });
});
