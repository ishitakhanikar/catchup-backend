let recordingTimer = null;
let seconds = 0;
let isRecording = false;
let recordedDataUrl = null;

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
    if (message.type === 'START_RECORDING') {
        startRecording()
            .then(() => sendResponse({success: true}))
            .catch(e => sendResponse({error: e.message}));
        return true; 
    } else if (message.type === 'STOP_RECORDING') {
        stopRecording()
            .then(() => sendResponse({success: true}))
            .catch(e => sendResponse({error: e.message}));
        return true;
    } else if (message.type === 'GET_STATE') {
        sendResponse({ isRecording, seconds, recordedDataUrl });
    } else if (message.type === 'FINAL_AUDIO_DATA') {
        recordedDataUrl = message.data;
        chrome.runtime.sendMessage({ type: 'RECORDING_COMPLETE', data: message.data }).catch(() => {});
        isRecording = false;
        clearInterval(recordingTimer);
    } else if (message.type === 'CLEAR_RECORDING') {
        recordedDataUrl = null;
        sendResponse({success: true});
    }
});

async function setupOffscreenDocument() {
    const existingContexts = await chrome.runtime.getContexts({
        contextTypes: ['OFFSCREEN_DOCUMENT']
    });
    if (existingContexts.length > 0) return;

    await chrome.offscreen.createDocument({
        url: 'offscreen.html',
        reasons: ['USER_MEDIA'],
        justification: 'Recording audio data from microphone'
    });
}

async function startRecording() {
    if (isRecording) return;
    recordedDataUrl = null;
    await setupOffscreenDocument();
    
    await chrome.runtime.sendMessage({
        target: 'offscreen',
        type: 'START_RECORDING'
    });
    
    isRecording = true;
    seconds = 0;
    
    recordingTimer = setInterval(() => {
        seconds++;
        chrome.runtime.sendMessage({ type: 'TIMER_UPDATE', seconds }).catch(() => {});
    }, 1000);
}

async function stopRecording() {
    if (!isRecording) return;
    clearInterval(recordingTimer);
    
    await chrome.runtime.sendMessage({
        target: 'offscreen',
        type: 'STOP_RECORDING'
    });
}
